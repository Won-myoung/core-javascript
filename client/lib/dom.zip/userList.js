import { insertLast } from "./insert.js"




function createUserCard({
    name = 'unknown',
    email = 'template@temp.com',
    website = 'temp.com'
}){

    return `
        <article class="user-card" data-index="user-1">
            <h3 class="user-name">${name}</h3>
            <div class="user-resouce-info">
                <div>
                    <a class="user-email" href="mailto:${email}">${email}</a>
                </div>
                <div>
                    <a class="user-website" href="${website}" target="_blank" rel="noopener noreferer">${website}</a>
                </div>
            </div>
            <button class="delete">삭제</button>
        </article>
        `

}





export function renderUserCard(target,data){
    insertLast(target,createUserCard(data))
}











